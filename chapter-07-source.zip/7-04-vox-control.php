<?php
$cmd = $_GET['cmd'];
$auth = $_GET['auth'];

if ($auth == "") {
  $auth = "public";
}
system("/usr/local/minerva/bin/msgrcv vox $auth $cmd &");
?>

