#include <SDL/SDL.h>

int main() {
   if (SDL_Init(SDL_INIT_JOYSTICK) < 0) {
        fprintf(stderr, "Couldn't initialize SDL: %s\n", SDL_GetError());
        exit(1);
   }

   SDL_JoystickEventState(SDL_ENABLE);
   SDL_Joystick *pJoystick = SDL_JoystickOpen(0);

   SDL_Event event;
   while(SDL_PollEvent(&event)) {
      switch(event.type) {
         case SDL_JOYBUTTONDOWN:
            // Use event.jbutton.which, event.jbutton.button, event.jbutton.state
            break;
      }
   }
   SDL_JoystickClose(pJoystick);

   return 0;
}

