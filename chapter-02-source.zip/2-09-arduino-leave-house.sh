#!/bin/bash

say default Goodbye

RAIN=`weatherstatus | head -n 1 | grep -i "[rain|shower]"`

if [ "$?" -eq 0 ]; then
   say default Remember your umbrella it might rain today.
   say default $RAIN
fi

