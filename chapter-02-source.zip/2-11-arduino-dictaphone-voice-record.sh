#!/bin/bash

LOGFILE=/var/log/voxrecordpid
DIR_INCOMING=/usr/local/media/voxrecord

if [ "$1" == "start" ]; then
  FILENAME=`mktemp -p $DIR_INCOMING`.wav
  arecord -f cd -t wav $FILENAME >/dev/null >/dev/null 2>&1 &
  PID=$!
  echo $PID >$LOGFILE
fi

if [ "$1" == "stop" ]; then
  PID=`cat $LOGFILE`
  kill $PID
  rm $LOGFILE
fi

