#!/bin/bash

DIR_INCOMING=/usr/local/media/voxrecord

rm -f $DIR_INCOMING/*

