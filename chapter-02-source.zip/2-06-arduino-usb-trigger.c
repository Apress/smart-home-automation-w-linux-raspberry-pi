// USB script trigger
#include <stdio.h>

char *szUSBDevice = "/dev/ttyUSB0";
int main() {
char v;

FILE *fp = fopen(szUSBDevice, "r");
if (!fp) {
  printf("Failed to open USB...");
  return 1;
}


while(1) {
 if (fread(&v, 1, 1, fp)) {
   if (v == '1') {
      // button pressed
   } else if (v == '0') {
      // button released
   } else {
      printf("%c", v);
      fflush(stdout);
   }
 }
}

return 0;
}


