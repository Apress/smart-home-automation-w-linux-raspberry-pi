say default welcome home
x10control default on lounge_light


