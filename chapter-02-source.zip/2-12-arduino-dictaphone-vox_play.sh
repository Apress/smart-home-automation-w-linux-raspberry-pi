#!/bin/bash

DIR_INCOMING=/usr/local/media/voxrecord

for F in "$DIR_INCOMING"/*.wav
do
   play $F
done

