cat ir/codes/tv/off | nc -q 0  -u 192.168.1.111 65432

