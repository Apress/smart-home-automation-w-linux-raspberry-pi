curl -H "Content-Type: application/json" -X POST -d '{"devicetype":"myhome"}' http://192.168.0.27/api/

