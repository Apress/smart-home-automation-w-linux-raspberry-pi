heyu turn studio on
heyu onstate studio
heyu bright lounge 5
heyu lightsoff _  # the underscore means current house code

