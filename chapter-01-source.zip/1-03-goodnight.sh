#!/bin/bash

wavplayer default play ~steev/media/good-night-gorgeous.wav
tweet Good night all

/usr/local/bin/heyu turn studio_light off
/usr/local/bin/heyu turn kitchen_light off
 
/usr/local/bin/heyu turn lounge_light off

shutdown –h now

