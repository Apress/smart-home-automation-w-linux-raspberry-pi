#!/usr/bin/php
<?php
array_shift($argv);     // ignore program name

$type = array_shift($argv);
$toAddr = array_shift($argv);
$message = implode(" ", $argv);

$fromAddr = "MinervaHome";

# Things get different now...
$uname = ' MyUserName';
$pword = 'MyPassword';

$message = urlencode($message);

$data = "uname=".$uname."&pword=".$pword."&message=".$message."&from=". $fromAddr."&selectednums=".$toAddr."&info=1&test=0";

$ch = curl_init('http://www.txtlocal.com/sendsmspost.php');
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$result = curl_exec($ch); 
curl_close($ch);
?>
