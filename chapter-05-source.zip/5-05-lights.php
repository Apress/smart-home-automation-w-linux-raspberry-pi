<?php

$cmd = $_GET['cmd'];

if ($cmd == "lightson") {
   system("heyu turn bedroom_light on");
}
else if ($cmd == "lightsoff") {
   system("heyu turn bedroom_light off");
}
?>
