#!/usr/bin/perl

my $status = `gnokii  --showsmsfolderstatus 2>/dev/null`;
$status=~/ME\s+(\d+)/;
my $count=$1;

for(my $msg=$lastCount;$msg<=$count;++$msg) {
  my $txt = `gnokii --getsms ME $msg $msg 2>/dev/null`;
  if ($txt=~/Inbox Message/) {
     $txt=~/Date\/time\:(.*?)\n.*?Sender\:(.*?)Msg.*?\n.*?Text\:\n(.*)/;

     my $date = $1;
     my $sender = $2;
     my $message = $3;

     # process here...
  }
}

