require 'cora' 
require 'siri_objects' 
require 'pp'   

class SiriProxy::Plugin::ControlLights < SiriProxy::Plugin   
   def initialize(config)     
      # standard initialization   
   end    

   listen_for /computer light (on|off)/i do |light_state|     
      state = `homedevice default #{light_state} bedroom_light`     
      say state     
      request_completed   
   end  
end

