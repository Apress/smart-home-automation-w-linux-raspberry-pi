<?php
$rt = "Web Echo...\n";

$rt.= "Get:\n";
$rt.= print_r($_GET, TRUE);

$rt.= "Post:\n";
$rt.= print_r($_POST, TRUE);

file_put_contents( '/tmp/log.txt', $rt, FILE_APPEND );
?>
