#!/bin/bash
while :
do
 echo Insert next disc...
 read x

 cdcd close
 abcde -N
 cdcd eject
done

