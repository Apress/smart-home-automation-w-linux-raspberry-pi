#!/bin/bash
LIST="$(ls *.wav)"
for FILE in "$LIST"; do
 flac $FILE
done

