#!/usr/bin/perl -w
use strict;
use WWW::Mechanize;
use HTML::TokeParser;

my $agent = WWW::Mechanize->new();
$agent->get("http://www.minervahome.net/news.htm");

my $stream = HTML::TokeParser->new(\$agent->{content});

foreach(1..4) {
   $stream->get_tag("table");
}


$stream->get_tag("td");
$stream->get_tag("td");


my @link = $stream->get_tag("a");

my $href = $link[0][1]{href};

my $storyHeadline = $stream->get_trimmed_text("/a");

$stream->get_tag("td"); 
print $stream->get_trimmed_text("/td");

?>
